"use client"

import  from ".."

export default function SyntheticV0PageForDeployment() {
  return < />
}